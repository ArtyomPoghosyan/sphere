export const minTextLimit: number = 0;
export const maxtextLimit: number = 50;
export const maxDateLimit: number = -5;
export const takeCount: number = 10;