export const transferStatusItems = [
    { id: '1', label: 'Pending' },
    { id: '2', label: 'Success' },
    { id: '3', label: 'Failed' },
    { id: '4', label: 'Refund' },
];