export const greenColor: string = " #04B358;";
export const whiteColor: string = "#FFFFFF";
export const greyColor: string = "#F8F8FA";
export const lightBlueGreen: string = "#f7f7f700";