export const FormInput: React.FC = () => {
    return (
        <div>
            
        </div>
    )
}