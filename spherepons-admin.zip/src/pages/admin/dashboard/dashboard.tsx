export const Dashboard:React.FC =() => {
    return (
        <div>
            Dashboard
        </div>

    )
}
